package com.example.inicial1.services;

import org.springframework.stereotype.Service;

@Service
public class PersonaServices {



}
